document.addEventListener("DOMContentLoaded", () => {

  const form = document.getElementById('form');
  const successMsg = document.getElementById('success');

  // Cegah error kalau form tidak ada
  if (!form) {
    console.error("Form tidak ditemukan!");
    return;
  }

  form.addEventListener('submit', (e) => {
    e.preventDefault();

    const formData = new FormData(form);

    const nama = formData.get("nama");
    const obat = formData.get("obat");
    const wa = formData.get("wa");

    if (!wa || wa.length < 10) {
      alert("Nomor WhatsApp tidak valid!");
      return;
    }

    // Tampilkan pesan sukses
    successMsg.style.display = 'block';

    // Redirect ke WhatsApp Admin
    setTimeout(() => {

      const pesan =
        `Halo Admin ApotekAI,%0A` +
        `Saya ${nama} ingin memesan:%0A` +
        `${obat}%0A%0A` +
        `Nomor WA Saya: ${wa}`;

      window.location.href =
        `https://wa.me/6285217171948?text=${pesan}`;

    }, 1000);

  });

});
